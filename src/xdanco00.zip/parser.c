/******************************** parser.c **********************************/
/*  Predmet: IFJ a IAL						                                  */
/*  Syntakticka a semanticka analyza                                          */
/*  Vytvorili: Frantisek Fudor xfudor00
    Marek Danco xdanco00
    Martin Olsiak xolsia00                                                    */
/* ************************************************************************** */

#include "parser.h"
#include <stdlib.h>

bool checkDatatype(dataType type, token *tok, tableNodePtr varTable) {

    data *var;
    switch (type) {
        case TYPE_STRING:
            if (tok->tokenType == STRING_LIT) return true;
            if ((var = copyNode(&varTable, tok->tokenName.data)) != NULL)
                if (var->types[0] == TYPE_STRING) return true;
            break;
        case TYPE_INT:
            if (tok->tokenType == INT_LIT) return true;
            if ((var = copyNode(&varTable, tok->tokenName.data)) != NULL)
                if (var->types[0] == TYPE_INT) return true;
            break;
        case TYPE_FLOAT:
            if (tok->tokenType == FLOAT_LIT) return true;
            if ((var = copyNode(&varTable, tok->tokenName.data)) != NULL)
                if (var->types[0] == TYPE_FLOAT) return true;
            break;
        default:
            break;
    }
    return false;
}

errorCode checkFunctionTypes(list *tokenList, data *func, size_t i, tableNodePtr localTable, dataType **back) {

    dataType *paramTypes = NULL;
    if (func->parameters != NULL) {
        paramTypes = malloc(sizeof(dataType) * (func->parameters->size / 2 + 1));
        if (!paramTypes) return INTERNAL_ERROR;
    }
    size_t typeCount = 0;

    // first, we need to check which parameter types function expects
    for (token *iter = func->parameters->first; iter != NULL; iter = iter->nextToken) {
        switch (iter->tokenType) {
            case INT:
                paramTypes[typeCount++] = TYPE_INT;
                break;
            case STRING:
                paramTypes[typeCount++] = TYPE_STRING;
                break;
            case FLOAT:
                paramTypes[typeCount++] = TYPE_FLOAT;
                break;
            default:
                break;
        }
    }
    paramTypes[typeCount] = TYPE_UNDEFINED;
    size_t nextCommaCount = 0;
    bool inParams = false;
    token *nextTok = NULL;
    nextTok = copyToken(tokenList, i + 1);
    for (size_t j = i + 1; nextTok != NULL; nextTok = copyToken(tokenList, ++j)) {
        if (!inParams && equalStrings(nextTok->tokenName.data, "("))
            inParams = true; // if we encounter (, we need to check parameters
        else if (inParams && equalStrings(nextTok->tokenName.data, ")"))
            break; // if we encounter ), we break the cycle
        else if (inParams && nextTok->tokenType == COMMA) { // when we reach a comma
            nextCommaCount++;
            if (nextCommaCount == typeCount) {
                // if there is same count of commas as of function params,
                // it means that there are more terms than needed. Return error.
                free(paramTypes);
                return PARAMETER_ERROR;
            }
        } else {
            if (inParams && !checkDatatype(paramTypes[nextCommaCount], nextTok, localTable)) {
                // if we have a term, we need to check for the right type. If it doesn't
                // correspond, return error
                free(paramTypes);
                return PARAMETER_ERROR;
            }
        }

    }
    if (typeCount != 0 && nextCommaCount + 1 != typeCount) {
        free(paramTypes);
        return PARAMETER_ERROR;
    }
    free(paramTypes);

    *back = func->types;
    return OK;
}

errorCode semanticAnalyser(list *tokenList, tableNodePtr *globalTable, tableNodePtr *localTable, data *function) {

    // ------------------------------ Checking datatype compatibility and zero division ------------------------------ //

    if (tokenList != NULL) {
        size_t tokCounter = 0;
        bool wasIf = false;
        bool wasFor = false;
        int semicolonCount = 0;
        for (token *tok = tokenList->first; tok != NULL; tok = tok->nextToken) {
            if (tok->tokenType == IF)
                wasIf = true;
            else if (tok->tokenType == FOR) // if we are in for, we can't control, because some variables may not be in symtable
                wasFor = true;
            else if (wasFor && tok->tokenType == SEMICOL)
                semicolonCount++;
            if (tok->nextToken != NULL) { // first check if there is next token
                token *operator = tok->nextToken;
                if (operator->tokenType == ARIT_OPERATOR ||
                    operator->tokenType == COMP_OPERATOR) { // then check if it's operator
                    if (!wasIf && !wasFor && operator->tokenType == COMP_OPERATOR) return TYPE_COMPATIBILITY_ERROR;
                    if (operator->nextToken !=
                        NULL) { // check if it has next token just to be sure (should be handled by syntax analysis)
                        if (equalStrings(operator->tokenName.data, "/") && // check if operator is division
                            (operator->nextToken->tokenType == INT_LIT ||
                             operator->nextToken->tokenType == FLOAT_LIT)) { // and check if next token is literal
                            // if next literal is zero, return ZERO_DIVISION_ERROR
                            bool wasDot = false;
                            bool isZero = true;
                            for (size_t i = 0; i < strlen(operator->nextToken->tokenName.data); i++) {
                                if (operator->nextToken->tokenName.data[i] != '0' &&
                                    operator->nextToken->tokenName.data[i] != '.') {
                                    isZero = false; // if current char isn't 0 or ., it means literal is not zero value
                                    break;
                                }
                                if (operator->nextToken->tokenName.data[i] == '.') { // there can be only one dot
                                    if (wasDot) {
                                        isZero = false;
                                        break;
                                    } else wasDot = true;
                                }
                            }
                            if (isZero) return ZERO_DIVISION_ERROR;
                        }

                        if (!wasFor || semicolonCount != 2) { // we can only check if we aren't in third portion of for
                            // checking type compatibility between variables/literals
                            size_t count = 0;
                            token *prevTok;
                            for (prevTok = tok; prevTok != NULL; prevTok = copyToken(tokenList, tokCounter - count)) {
                                // run through tokens until we reach something which isn't ")"
                                if (!equalStrings(prevTok->tokenName.data, ")")) // if token isn't ), that means we got variable or literal
                                    break;
                                count++;
                            }

                            data *var = copyNode(localTable, prevTok->tokenName.data);
                            bool varString = false;
                            bool varInt = false;
                            bool varFloat = false;
                            if (var != NULL) {
                                varString = (var->types[0] == TYPE_STRING);
                                varInt = (var->types[0] == TYPE_INT);
                                varFloat = (var->types[0] == TYPE_FLOAT);
                            }
                            if (prevTok->tokenType == STRING_LIT ||
                                varString) { // if first token was string, operator cannot be - * /
                                if (equalStrings(operator->tokenName.data, "-")) return TYPE_COMPATIBILITY_ERROR;
                                if (equalStrings(operator->tokenName.data, "*")) return TYPE_COMPATIBILITY_ERROR;
                                if (equalStrings(operator->tokenName.data, "/")) return TYPE_COMPATIBILITY_ERROR;
                                for (token *nextTok = operator->nextToken;
                                     nextTok != NULL; nextTok = nextTok->nextToken) {
                                    if (!equalStrings(nextTok->tokenName.data, "(")) {
                                        // run through next tokens until variable or literal is reached
                                        if (!checkDatatype(TYPE_STRING, nextTok, *localTable))
                                            return TYPE_COMPATIBILITY_ERROR;
                                        else break;
                                    }
                                }
                            } else if (prevTok->tokenType == INT_LIT || varInt) {
                                for (token *nextTok = operator->nextToken;
                                     nextTok != NULL; nextTok = nextTok->nextToken) {
                                    if (!equalStrings(nextTok->tokenName.data, "(")) {
                                        // run through next tokens until variable or literal is reached
                                        if (!checkDatatype(TYPE_INT, nextTok, *localTable))
                                            return TYPE_COMPATIBILITY_ERROR;
                                        else break;
                                    }
                                }
                            } else if (prevTok->tokenType == FLOAT_LIT || varFloat) {
                                for (token *nextTok = operator->nextToken;
                                     nextTok != NULL; nextTok = nextTok->nextToken) {
                                    if (!equalStrings(nextTok->tokenName.data, "(")) {
                                        // run through next tokens until variable or literal is reached
                                        if (!checkDatatype(TYPE_FLOAT, nextTok, *localTable))
                                            return TYPE_COMPATIBILITY_ERROR;
                                        else break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            tokCounter++;
        }

        if (tokenList->first != NULL) { // all the next checks require first token, so checking if it's not null

            // ------------------------------ Checking if scope has ended ------------------------------ //

            if (equalStrings(tokenList->first->tokenName.data, "}")) {
                if (scope != 0) { // if we aren't in the end of function
                    invalidateScope(localTable, scope); // invalidate two scopes and decrease the scope two times
                    scope--;
                    invalidateScope(localTable, scope);
                    scope--;
                } else // else we are at the end of function, so delete the whole local variable symtable
                    deleteTable(localTable);
            }

            // ------------------------------ Checking if semantics ------------------------------ //

            if (tokenList->first->tokenType == IF) {
                bool wasComparator = false;
                size_t wasBracket = 0;
                for (token *tok = tokenList->first->nextToken;
                     tok != NULL; tok = tok->nextToken) {
                    if (equalStrings(tok->tokenName.data, "("))
                        wasBracket++; // if we encounter opening bracket, increase bracket count
                    else if (equalStrings(tok->tokenName.data, ")"))
                        wasBracket--; // decrease with closing bracket
                    else if (tok->tokenType == COMP_OPERATOR) {
                        if (wasComparator || wasBracket) return SEMANTIC_ERROR;
                        // if there was more than one comparator or comparator was in brackets, return general semantic error
                        wasComparator = true;
                    }
                }
                if (!wasComparator) return TYPE_COMPATIBILITY_ERROR; // if there was no comparator, return compatibility error
                scope += 2; // increasing the scope twice since we are entering if
            }

            // checking else
            if (tokenList->first->nextToken != NULL) {
                if (tokenList->first->nextToken->tokenType ==
                    ELSE) { // else should always be second token, if it is there
                    scope += 2; // just increase the scope, because there is no comparing with else
                }
            }

            // ------------------------------ Checking for semantics ------------------------------ //

            if (tokenList->first->tokenType == FOR) {
                scope++; // increasing the scope for the first line
                semicolonCount = 0;
                bool wasComparator = false;
                size_t wasBracket = 0;
                bool wasDefinition = false;
                bool decidedType = false;
                token *newSymbol;
                for (token *tok = tokenList->first->nextToken; // we need to begin from second one, since first token is just for keyword
                     tok != NULL; tok = tok->nextToken) {
                    if (tok->tokenType == SEMICOL) {
                        semicolonCount++;
                        if (semicolonCount == 2 && wasComparator == false) // if we are after second semicolon and there
                            // was no comparator, we aren't getting bool value, so return error.
                            return TYPE_COMPATIBILITY_ERROR;
                    } else if (equalStrings(tok->tokenName.data, ":="))
                        wasDefinition = true;
                    else if (semicolonCount == 0) { // if there wasn't a semicolon, we are in definition part
                        if (tok->tokenType == IDENT &&
                            !wasDefinition) // if this is the identifier before definition token
                            newSymbol = tok; // store the token for future use
                        else if (wasDefinition && !decidedType) {

                            token *nextTok; // create next token, which should define the type of newSymbol
                            for (nextTok = tok; nextTok != NULL; nextTok = nextTok->nextToken) {
                                // run through next tokens until variable or literal is reached
                                if (!equalStrings(nextTok->tokenName.data, "("))
                                    break;
                            }

                            decidedType = true; // we are going to add this to symtable, so setting this so we don't do it again
                            dataType *type = malloc(sizeof(dataType) * 2);
                            if (!type) return INTERNAL_ERROR;
                            bool isVar = false;
                            switch (nextTok->tokenType) { // token type just before the semicolon should only be a literal or identifier
                                case INT_LIT:
                                    type[0] = TYPE_INT;
                                    break;
                                case STRING_LIT:
                                    type[0] = TYPE_STRING;
                                    break;
                                case FLOAT_LIT:
                                    type[0] = TYPE_FLOAT;
                                    break;
                                case IDENT:
                                    isVar = true;
                                    break;
                                default: // shouldn't be any other type, so just breaking. Syntax error should occur if this is the case
                                    break;
                            }
                            if (isVar) { // if it was identifier, further checking is needed
                                data *lastVar;
                                if ((lastVar = copyNode(localTable, nextTok->tokenName.data)) == NULL) {
                                    // if searching in local table yields no results, this variable was undefined
                                    free(type);
                                    return DEFINITION_ERROR;
                                } else {
                                    switch (lastVar->types[0]) {
                                        case TYPE_INT:
                                            type[0] = TYPE_INT;
                                            break;
                                        case TYPE_FLOAT:
                                            type[0] = TYPE_FLOAT;
                                            break;
                                        case TYPE_STRING:
                                            type[0] = TYPE_STRING;
                                            break;
                                        default:
                                            free(type);
                                            return DEFINITION_ERROR;
                                    }
                                }
                            }
                            type[1] = TYPE_UNDEFINED;
                            insertNode(localTable, newSymbol->tokenName.data, type, NULL, scope);

                        }
                    } else if (semicolonCount == 1) { // if there was one semicolon, we are in the comparing part
                        if (tok->tokenType == COMP_OPERATOR) {
                            if (wasComparator || wasBracket) return SEMANTIC_ERROR;
                                // if there was more than one comparator or comparator is in brackets, return general semantic error
                            else wasComparator = true;
                        } else if (equalStrings(tok->tokenName.data, "("))
                            wasBracket++;
                        else if (equalStrings(tok->tokenName.data, ")"))
                            wasBracket--;
                    } else {
                        token *operator = tok->nextToken;
                        if (operator != NULL && operator->tokenType == ARIT_OPERATOR) {
                            size_t count = 0;
                            token *prevTok;
                            for (prevTok = tok; prevTok != NULL; prevTok = copyToken(tokenList, tokCounter - count)) {
                                // run through tokens until we reach something which isn't ")"
                                if (!equalStrings(prevTok->tokenName.data,
                                                  ")")) // if token isn't ), that means we got variable or literal
                                    break;
                                count++;
                            }

                            data *var = copyNode(localTable, prevTok->tokenName.data);
                            bool varString = false;
                            bool varInt = false;
                            bool varFloat = false;
                            if (var != NULL) {
                                varString = (var->types[0] == TYPE_STRING);
                                varInt = (var->types[0] == TYPE_INT);
                                varFloat = (var->types[0] == TYPE_FLOAT);
                            }
                            if (prevTok->tokenType == STRING_LIT ||
                                varString) { // if first token was string, operator cannot be - * /
                                if (equalStrings(operator->tokenName.data, "-")) return TYPE_COMPATIBILITY_ERROR;
                                if (equalStrings(operator->tokenName.data, "*")) return TYPE_COMPATIBILITY_ERROR;
                                if (equalStrings(operator->tokenName.data, "/")) return TYPE_COMPATIBILITY_ERROR;
                                for (token *nextTok = operator->nextToken;
                                     nextTok != NULL; nextTok = nextTok->nextToken) {
                                    if (!equalStrings(nextTok->tokenName.data, "(")) {
                                        // run through next tokens until variable or literal is reached
                                        if (!checkDatatype(TYPE_STRING, nextTok, *localTable))
                                            return TYPE_COMPATIBILITY_ERROR;
                                        else break;
                                    }
                                }
                            } else if (prevTok->tokenType == INT_LIT || varInt) {
                                for (token *nextTok = operator->nextToken;
                                     nextTok != NULL; nextTok = nextTok->nextToken) {
                                    if (!equalStrings(nextTok->tokenName.data, "(")) {
                                        // run through next tokens until variable or literal is reached
                                        if (!checkDatatype(TYPE_INT, nextTok, *localTable))
                                            return TYPE_COMPATIBILITY_ERROR;
                                        else break;
                                    }
                                }
                            } else if (prevTok->tokenType == FLOAT_LIT || varFloat) {
                                for (token *nextTok = operator->nextToken;
                                     nextTok != NULL; nextTok = nextTok->nextToken) {
                                    if (!equalStrings(nextTok->tokenName.data, "(")) {
                                        // run through next tokens until variable or literal is reached
                                        if (!checkDatatype(TYPE_FLOAT, nextTok, *localTable))
                                            return TYPE_COMPATIBILITY_ERROR;
                                        else break;
                                    }
                                }
                            }
                        }
                    }
                }
                scope++; // increasing the scope again after first line
            }

            // ------------------------------ Checking definition semantics ------------------------------ //

            for (token *tok = tokenList->first; tok != NULL; tok = tok->nextToken) {
                if (tok->nextToken != NULL && equalStrings(tok->nextToken->tokenName.data, ":=")) {
                    // if this is the definition command, create new entry in symtable
                    data *thisSymbol;
                    if (equalStrings(tok->tokenName.data, "_")) return DEFINITION_ERROR;

                    thisSymbol = copyNode(localTable, tok->tokenName.data);
                    bool isNull = thisSymbol == NULL;
                    if (isNull || scope > thisSymbol->scope || !thisSymbol->defined) {
                        dataType *newType = malloc(sizeof(dataType) * 2);
                        if (!newType) return INTERNAL_ERROR;
                        for (token *nextTok = tok->nextToken; nextTok != NULL; nextTok = nextTok->nextToken) {
                            // with this cycle, we decide which datatype the variable should be
                            if (nextTok->tokenType == IDENT) {
                                data *var = copyNode(localTable, nextTok->tokenName.data);
                                if (var == NULL) {
                                    free(newType);
                                    return DEFINITION_ERROR;
                                }
                                switch (var->types[0]) {
                                    case TYPE_INT:
                                        newType[0] = TYPE_INT;
                                        break;
                                    case TYPE_FLOAT:
                                        newType[0] = TYPE_FLOAT;
                                        break;
                                    case TYPE_STRING:
                                        newType[0] = TYPE_STRING;
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            } else if (nextTok->tokenType == INT_LIT) {
                                newType[0] = TYPE_INT;
                                break;
                            } else if (nextTok->tokenType == STRING_LIT) {
                                newType[0] = TYPE_STRING;
                                break;
                            } else if (nextTok->tokenType == FLOAT_LIT) {
                                newType[0] = TYPE_FLOAT;
                                break;
                            }
                        }

                        if (isNull || thisSymbol->defined) {
                            newType[1] = TYPE_UNDEFINED;
                            if (insertNode(localTable, tok->tokenName.data, newType, NULL, scope))
                                return INTERNAL_ERROR;
                        }
                            // scope won't be overwritten, since variable already is in there
                        else {
                            thisSymbol->defined = true;
                            free(thisSymbol->types);
                            thisSymbol->types = newType;
                            thisSymbol->scope = scope; // scope will be overwritten, since we are defining it again
                        }
                    } else return DEFINITION_ERROR;
                } else if (tok->tokenType == IDENT && (!equalStrings(tok->tokenName.data, "_")) &&
                           (!equalStrings(tok->tokenName.data, "print"))) {
                    if (copyNode(globalTable, tok->tokenName.data) == NULL &&
                        copyNode(localTable, tok->tokenName.data) == NULL)
                        return DEFINITION_ERROR;
                }
            }

            // ------------------------------ Checking return semantics ------------------------------ //

            if (tokenList->first->tokenType == RETURN) { // if we are returning from the function
                size_t commaCounter = 0; // for knowing which return value are we checking
                size_t typeCount = 0; // for knowing how much types we have to control
                dataType *types = function->types;
                for (dataType type = types[0]; type != TYPE_UNDEFINED; type = types[++typeCount]);
                if (typeCount != 0) {
                    for (token *tok = tokenList->first->nextToken; tok != NULL; tok = tok->nextToken) {
                        if (tok->tokenType == COMMA) { // if we are at a coma, just increase the counter
                            commaCounter++;
                            if (commaCounter >= typeCount) return PARAMETER_ERROR;
                            // if commaCounter is bigger than it should, jump out of function right away
                        } else if (tok->tokenType == IDENT || tok->tokenType == INT_LIT || tok->tokenType == STRING_LIT || tok->tokenType == FLOAT_LIT) {

                            // return expressions must have the same data types as all variables/literals in expressions

                            if (types[commaCounter] == TYPE_INT) {
                                if (tok->tokenType != INT_LIT) { // if it's correct literal, we don't have to check
                                    if (!checkDatatype(TYPE_INT, tok, *localTable))
                                        return PARAMETER_ERROR;
                                }
                            } else if (types[commaCounter] == TYPE_STRING) {
                                if (tok->tokenType != STRING_LIT) {
                                    if (!checkDatatype(TYPE_STRING, tok, *localTable))
                                        return PARAMETER_ERROR;
                                }
                            } else if (types[commaCounter] == TYPE_FLOAT) {
                                if (tok->tokenType != FLOAT_LIT) {
                                    if (!checkDatatype(TYPE_FLOAT, tok, *localTable))
                                        return PARAMETER_ERROR;
                                }
                            }
                        }
                    }
                }
                if ((typeCount == 0 && tokenList->first != tokenList->last) ||
                        (typeCount > 0 && commaCounter + 1 != typeCount))
                    return PARAMETER_ERROR;
                // if there wasn't same count of different expressions as return types, return error

            }

            // ------------------------------ Checking assign semantics ------------------------------ //

            for (size_t i = 0; i < tokenList->size; i++) { // we run through the list with a number so we can come back
                token *tok = NULL;
                tok = copyToken(tokenList, i);
                if (equalStrings(tok->tokenName.data, "=")) { // if we encounter =, it means this is assign
                    size_t prevCommaCount = 0; // comma counts to check the same number of expressions
                    size_t nextCommaCount = 0;
                    token *prevTok = NULL;
                    prevTok = copyToken(tokenList, i - 1); // previous token to check before the = operator
                    token *nextTok = NULL;
                    nextTok = copyToken(tokenList, i + 1); // next token to check after the = operator

                    dataType *prevTypes = NULL; // types that are before operator
                    dataType *nextTypes = NULL; // types that are after the operator

                    for (size_t j = i - 1; j != 0 && prevTok != NULL; prevTok = copyToken(tokenList, --j)) {
                        // before the = operator, there should only be commas and variable identifiers.

                        if (prevTok->tokenType == COMMA)
                            prevCommaCount++;
                        else if (prevTok->tokenType != IDENT)
                            break;
                    }

                    data *func;
                    if ((func = copyNode(globalTable, nextTok->tokenName.data)) == NULL) {
                        // after the = operator, there can be function or a list of
                        // expressions separated by commas.
                        for (size_t j = i + 1; nextTok != NULL; nextTok = copyToken(tokenList, ++j)) {
                            // if there isn't a function, we need to count the commas
                            if (nextTok->tokenType == COMMA)
                                nextCommaCount++;
                            else if (nextTok->tokenType == COMP_OPERATOR)
                                return DATATYPE_ERROR;
                                // if there was comparator, that is not the right type to assign
                            else if (nextTok->tokenType != IDENT &&
                                     nextTok->tokenType != BRACKET_ROUND &&
                                     nextTok->tokenType != ARIT_OPERATOR &&
                                     nextTok->tokenType != INT_LIT &&
                                     nextTok->tokenType != STRING_LIT &&
                                     nextTok->tokenType != FLOAT_LIT)
                                break;
                            // if it isn't any of these types, we are out of the expression, so break the cycle
                        }
                    } else { // if there is a function, we need to check type compatibility with its parameters

                        errorCode code;
                        if ((code = checkFunctionTypes(tokenList, func, i, *localTable, &nextTypes)) != OK)
                            return code;

                    }

                    if (func == NULL) {
                        if (prevCommaCount != nextCommaCount) // if there was no function, comma counts should be equal
                            return SEMANTIC_ERROR;

                        nextTypes = malloc(sizeof(dataType) * (nextCommaCount + 2));
                        if (!nextTypes) return INTERNAL_ERROR;
                        for (size_t j = 0; j < nextCommaCount + 2; j++)
                            nextTypes[j] = TYPE_UNDEFINED;
                        // if there was no function, we need to check next data types term after term
                        nextTok = copyToken(tokenList, i + 1); // begin the iteration from start again
                        nextCommaCount = 0;
                        for (size_t j = i + 1; nextTok != NULL; nextTok = copyToken(tokenList, ++j)) {
                            if (nextTok->tokenType == COMMA)
                                nextCommaCount++;
                            else {
                                if (checkDatatype(TYPE_INT, nextTok, *localTable))
                                    nextTypes[nextCommaCount] = TYPE_INT;
                                else if (checkDatatype(TYPE_STRING, nextTok, *localTable))
                                    nextTypes[nextCommaCount] = TYPE_STRING;
                                else if (checkDatatype(TYPE_FLOAT, nextTok, *localTable))
                                    nextTypes[nextCommaCount] = TYPE_FLOAT;
                            }
                        }
                    }
                    prevTypes = malloc(sizeof(dataType) * (prevCommaCount + 2));
                    if (!prevTypes) {
                        free(nextTypes);
                        return INTERNAL_ERROR;
                    }
                    for (size_t j = 0; j < prevCommaCount + 2; j++)
                        prevTypes[j] = TYPE_UNDEFINED;
                    prevTok = copyToken(tokenList, 0); // begin the iteration from start again
                    prevCommaCount = 0;
                    for (size_t j = 0;
                         prevTok != NULL && prevTok->tokenType != ASIGN_OPERATOR; prevTok = copyToken(tokenList, ++j)) {
                        if (prevTok->tokenType == COMMA)
                            prevCommaCount++;
                        else {
                            if (checkDatatype(TYPE_INT, prevTok, *localTable))
                                prevTypes[prevCommaCount] = TYPE_INT;
                            else if (checkDatatype(TYPE_STRING, prevTok, *localTable))
                                prevTypes[prevCommaCount] = TYPE_STRING;
                            else if (checkDatatype(TYPE_FLOAT, prevTok, *localTable))
                                prevTypes[prevCommaCount] = TYPE_FLOAT;
                        }
                    }

                    for (size_t j = 0; j < prevCommaCount +
                                           1; j++) { // at the end, iterate one last time to check if data types match
                        if (nextTypes[j] != prevTypes[j] && prevTypes[j] != TYPE_UNDEFINED) {
                            // we need to add TYPE_UNDEFINED here in case one of prev identifiers was _ and undefined stayed with it
                            free(nextTypes);
                            free(prevTypes);
                            return TYPE_COMPATIBILITY_ERROR;
                        }
                    }
                    free(prevTypes);
                    free(nextTypes);

                    break;
                }
            }

            // ------------------------------ Checking function call semantics ------------------------------ //

            data *func;
            if ((func = copyNode(globalTable, tokenList->first->tokenName.data)) !=
                NULL) { // if we use function without assign
                dataType *types = NULL;
                errorCode code;
                if ((code = checkFunctionTypes(tokenList, func, 0, *localTable,
                                               &types))) // check if types had been correctly assigned
                    return code;
                else if (types[0] != TYPE_UNDEFINED) // if yes, check if function has no returns
                    return SEMANTIC_ERROR;
            }

        }
    }
    return OK;

}

errorCode fillSymtable(tableNodePtr *globalTable, list *tokenList) {

    errorCode out;

    ///FUNC INPUTS
    string funcId;
    initString(&funcId);
    out = makeString("inputs", &funcId);
    if (out) return out;

    dataType *funcInputsRetTypes = malloc(3 * sizeof(dataType));
    if (!funcInputsRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcInputsRetTypes[0] = TYPE_STRING;
    funcInputsRetTypes[1] = TYPE_INT;
    funcInputsRetTypes[2] = TYPE_UNDEFINED;

    list *funcInputsParams = malloc(sizeof(list));
    if (!funcInputsParams) {
        free(funcInputsRetTypes);
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    initList(funcInputsParams);

    out = insertNode(globalTable, funcId.data, funcInputsRetTypes, funcInputsParams, 0);

    destroyString(&funcId);
    if (out) {
        free(funcInputsRetTypes);
        free(funcInputsParams);
        destroyString(&funcId);
        return out;
    }

    ///FUNC INPUTI
    out = makeString("inputi", &funcId);
    if (out) return out;

    dataType *funcInputiRetTypes = malloc(3 * sizeof(dataType));
    if (!funcInputiRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcInputiRetTypes[0] = TYPE_INT;
    funcInputiRetTypes[1] = TYPE_INT;
    funcInputiRetTypes[2] = TYPE_UNDEFINED;

    list *funcInputiParams = malloc(sizeof(list));
    if (!funcInputiParams) {
        destroyString(&funcId);
        free(funcInputiRetTypes);
    }
    initList(funcInputiParams);

    out = insertNode(globalTable, funcId.data, funcInputiRetTypes, funcInputiParams, 0);

    destroyString(&funcId);
    if (out) {
        free(funcInputiRetTypes);
        free(funcInputiParams);
        destroyString(&funcId);
        return out;
    }

    ///FUNC INPUTF
    out = makeString("inputf", &funcId);
    if (out) return out;

    dataType *funcInputfRetTypes = malloc(3 * sizeof(dataType));
    if (!funcInputfRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcInputfRetTypes[0] = TYPE_INT;
    funcInputfRetTypes[1] = TYPE_INT;
    funcInputfRetTypes[2] = TYPE_UNDEFINED;

    list *funcInputfParams = malloc(sizeof(list));
    if (!funcInputfParams) {
        destroyString(&funcId);
        free(funcInputfRetTypes);
    }
    initList(funcInputfParams);

    out = insertNode(globalTable, funcId.data, funcInputfRetTypes, funcInputfParams, 0);

    destroyString(&funcId);
    if (out) {
        free(funcInputfRetTypes);
        free(funcInputfParams);
        destroyString(&funcId);
        return out;
    }

    ///FUNC INT2FLOAT
    out = makeString("int2float", &funcId);
    if (out) return out;

    dataType *funcInt2FloatRetTypes = malloc(2 * sizeof(dataType));
    if (!funcInt2FloatRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcInt2FloatRetTypes[0] = TYPE_FLOAT;
    funcInt2FloatRetTypes[1] = TYPE_UNDEFINED;

    list *funcInt2FloatParams = malloc(sizeof(list));
    if (!funcInt2FloatParams) {
        destroyString(&funcId);
        free(funcInt2FloatRetTypes);
    }
    initList(funcInt2FloatParams);

    string funcParamId;
    initString(&funcParamId);
    out = makeString("i", &funcParamId);
    if (out) {
        destroyString(&funcId);
        destroyString(&funcParamId);
        free(funcInt2FloatRetTypes);
        free(funcInt2FloatParams);
        return out;
    }

    token funcParam;
    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;

    out = addToken(funcInt2FloatParams, funcParam.tokenType, funcParam.tokenName.data);
    if (out) {
        destroyString(&funcId);
        destroyString(&funcParamId);
        free(funcInt2FloatRetTypes);
        deleteList(funcInt2FloatParams);
        free(funcInt2FloatParams);
        return out;
    }

    out = makeString("int", &funcParamId);
    if (out) {
        destroyString(&funcId);
        destroyString(&funcParamId);
        free(funcInt2FloatRetTypes);
        deleteList(funcInt2FloatParams);
        free(funcInt2FloatParams);
        return out;
    }

    funcParam.tokenType = INT;
    funcParam.tokenName = funcParamId;
    out = addToken(funcInt2FloatParams, funcParam.tokenType, funcParam.tokenName.data);
    if (out) {
        destroyString(&funcId);
        destroyString(&funcParamId);
        free(funcInt2FloatRetTypes);
        deleteList(funcInt2FloatParams);
        free(funcInt2FloatParams);
        return out;
    }

    out = insertNode(globalTable, funcId.data, funcInt2FloatRetTypes, funcInt2FloatParams, 0);

    destroyString(&funcId);
    if (out) {
        deleteList(funcInt2FloatParams);
        destroyString(&funcParamId);
        free(funcInt2FloatParams);
        free(funcInt2FloatRetTypes);
        destroyString(&funcId);
        return out;
    }

    ///FUNC FLOAT2INT
    out = makeString("float2int", &funcId);
    if (out) return out;

    dataType *funcFloat2IntRetTypes = malloc(2 * sizeof(dataType));
    if (!funcFloat2IntRetTypes) {
        destroyString(&funcParamId);
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcFloat2IntRetTypes[0] = TYPE_INT;
    funcFloat2IntRetTypes[1] = TYPE_UNDEFINED;

    list *funcFloat2IntParams = malloc(sizeof(list));
    if (!funcFloat2IntParams) {
        destroyString(&funcParamId);
        destroyString(&funcId);
        free(funcFloat2IntRetTypes);
    }
    initList(funcFloat2IntParams);

    out = makeString("f", &funcParamId);
    if (out) {
        destroyString(&funcParamId);
        free(funcFloat2IntRetTypes);
        free(funcInt2FloatParams);
        destroyString(&funcId);
        return out;
    }

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;

    out = addToken(funcFloat2IntParams, funcParam.tokenType, funcParam.tokenName.data);
    if (out) {
        destroyString(&funcParamId);
        free(funcFloat2IntRetTypes);
        deleteList(funcFloat2IntParams);
        free(funcInt2FloatParams);
        destroyString(&funcId);
        return out;
    }

    out = makeString("float64", &funcParamId);
    if (out) {
        destroyString(&funcParamId);
        free(funcFloat2IntRetTypes);
        deleteList(funcFloat2IntParams);
        free(funcInt2FloatParams);
        destroyString(&funcId);
        return out;
    }

    funcParam.tokenType = FLOAT;
    funcParam.tokenName = funcParamId;

    out = addToken(funcFloat2IntParams, funcParam.tokenType, funcParam.tokenName.data);
    if (out) {
        destroyString(&funcParamId);
        free(funcFloat2IntRetTypes);
        deleteList(funcFloat2IntParams);
        free(funcInt2FloatParams);
        destroyString(&funcId);
        return out;
    }
    out = insertNode(globalTable, funcId.data, funcFloat2IntRetTypes, funcFloat2IntParams, 0);

    destroyString(&funcId);
    if (out) {
        destroyString(&funcParamId);
        free(funcFloat2IntRetTypes);
        deleteList(funcFloat2IntParams);
        free(funcInt2FloatParams);
        destroyString(&funcId);
        return out;
    }

    ///FUNC LEN
    out = makeString("len", &funcId);
    if (out) return out;

    dataType *funcLenRetTypes = malloc(2 * sizeof(dataType));
    if (!funcLenRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcLenRetTypes[0] = TYPE_INT;
    funcLenRetTypes[1] = TYPE_UNDEFINED;

    list *funcLenParams = malloc(sizeof(list));
    if (!funcLenParams) {
        destroyString(&funcId);
        free(funcLenRetTypes);
    }
    initList(funcLenParams);

    out = makeString("s", &funcParamId);
    if (out) {
        free(funcLenParams);
        free(funcLenRetTypes);
        destroyString(&funcId);
        return out;
    }

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;

    out = addToken(funcLenParams, funcParam.tokenType, funcParam.tokenName.data);
    if (out) {
        deleteList(funcLenParams);
        free(funcLenParams);
        free(funcLenRetTypes);
        destroyString(&funcId);
        return out;
    }

    out = makeString("string", &funcParamId);
    if (out) {
        deleteList(funcLenParams);
        free(funcLenParams);
        free(funcLenRetTypes);
        destroyString(&funcId);
        destroyString(&funcParamId);
        return out;
    }

    funcParam.tokenType = STRING;
    funcParam.tokenName = funcParamId;

    addToken(funcLenParams, funcParam.tokenType, funcParam.tokenName.data);
    out = insertNode(globalTable, funcId.data, funcLenRetTypes, funcLenParams, 0);

    destroyString(&funcId);
    if (out) {
        free(funcLenRetTypes);
        deleteList(funcLenParams);
        free(funcLenParams);
        return out;
    }

    ///FUNC SUBSTR
    out = makeString("substr", &funcId);
    if (out) return out;

    dataType *funcSubstrRetTypes = malloc(3 * sizeof(dataType));
    if (!funcSubstrRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcSubstrRetTypes[0] = TYPE_STRING;
    funcSubstrRetTypes[1] = TYPE_INT;
    funcSubstrRetTypes[2] = TYPE_UNDEFINED;

    list *funcSubstrParams = malloc(sizeof(list));
    if (!funcSubstrParams) {
        destroyString(&funcId);
        free(funcSubstrRetTypes);
    }
    initList(funcSubstrParams);

    makeString("s", &funcParamId);

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("string", &funcParamId);

    funcParam.tokenType = STRING;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString(",", &funcParamId);

    funcParam.tokenType = COMMA;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("i", &funcParamId);

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("int", &funcParamId);

    funcParam.tokenType = INT;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString(",", &funcParamId);

    funcParam.tokenType = COMMA;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("n", &funcParamId);

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("int", &funcParamId);

    funcParam.tokenType = INT;
    funcParam.tokenName = funcParamId;
    addToken(funcSubstrParams, funcParam.tokenType, funcParam.tokenName.data);

    out = insertNode(globalTable, funcId.data, funcSubstrRetTypes, funcSubstrParams, 0);

    destroyString(&funcId);
    if (out) {
        free(funcSubstrRetTypes);
        deleteList(funcSubstrParams);
        free(funcSubstrParams);
        return out;
    }

    ///FUNC ORD
    out = makeString("ord", &funcId);
    if (out) return out;

    dataType *funcOrdRetTypes = malloc(3 * sizeof(dataType));
    if (!funcOrdRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcOrdRetTypes[0] = TYPE_INT;
    funcOrdRetTypes[1] = TYPE_INT;
    funcOrdRetTypes[2] = TYPE_UNDEFINED;

    list *funcOrdParams = malloc(sizeof(list));
    if (!funcOrdParams) {
        destroyString(&funcId);
        free(funcOrdRetTypes);
    }
    initList(funcOrdParams);

    makeString("s", &funcParamId);

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;
    addToken(funcOrdParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("string", &funcParamId);

    funcParam.tokenType = STRING;
    funcParam.tokenName = funcParamId;
    addToken(funcOrdParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString(",", &funcParamId);

    funcParam.tokenType = COMMA;
    funcParam.tokenName = funcParamId;
    addToken(funcOrdParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("i", &funcParamId);

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;
    addToken(funcOrdParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("int", &funcParamId);

    funcParam.tokenType = INT;
    funcParam.tokenName = funcParamId;
    addToken(funcOrdParams, funcParam.tokenType, funcParam.tokenName.data);

    out = insertNode(globalTable, funcId.data, funcOrdRetTypes, funcOrdParams, 0);

    destroyString(&funcId);
    if (out) {
        free(funcOrdRetTypes);
        deleteList(funcOrdParams);
        free(funcOrdParams);
        return out;
    }

    ///FUNC CHR
    out = makeString("chr", &funcId);
    if (out) return out;

    dataType *funcChrRetTypes = malloc(3 * sizeof(dataType));
    if (!funcChrRetTypes) {
        destroyString(&funcId);
        return INTERNAL_ERROR;
    }
    funcChrRetTypes[0] = TYPE_STRING;
    funcChrRetTypes[1] = TYPE_INT;
    funcChrRetTypes[2] = TYPE_UNDEFINED;

    list *funcChrParams = malloc(sizeof(list));
    if (!funcChrParams) {
        destroyString(&funcId);
        free(funcChrRetTypes);
    }
    initList(funcChrParams);

    makeString("i", &funcParamId);

    funcParam.tokenType = IDENT;
    funcParam.tokenName = funcParamId;
    addToken(funcChrParams, funcParam.tokenType, funcParam.tokenName.data);

    makeString("int", &funcParamId);

    funcParam.tokenType = INT;
    funcParam.tokenName = funcParamId;
    addToken(funcChrParams, funcParam.tokenType, funcParam.tokenName.data);

    out = insertNode(globalTable, funcId.data, funcChrRetTypes, funcChrParams, 0);

    destroyString(&funcId);
    if (out) {
        free(funcChrRetTypes);
        deleteList(funcChrParams);
        free(funcChrParams);
        return out;
    }

    size_t length = tokenList->size;

    for (size_t i = 0; i < length; i++) { // run through the whole token list

        string funcIdent;
        initString(&funcIdent);
        token func;
        getToken(tokenList, i, &func);

        if (func.tokenType == FUNC) {  // *FUNC* ...

            if (func.nextToken != NULL && func.nextToken->tokenType == IDENT) { // if next token is ident
                i++; // increase iterator
                token ident;
                initString(&ident.tokenName);
                getToken(tokenList, i, &ident); // get the identifier token
                makeString(ident.tokenName.data, &funcIdent); //uloží identifikator do stringu

                if (equalStrings(funcIdent.data, "main")) { // if identifier is main, ignore it
                    destroyString(&funcIdent);
                    continue;
                }

                if (ident.nextToken != NULL &&
                    equalStrings("(", ident.nextToken->tokenName.data)) { // if next token is opening bracket
                    i += 2; // increase past the bracket
                    token param;

                    list *parameters = malloc(sizeof(list)); // create the list for storing parameters
                    if (!parameters) return INTERNAL_ERROR;
                    initList(parameters); //list parametrov

                    getToken(tokenList, i, &param); // FUNC IDENT ( *IDENT* ...

                    while (!equalStrings(")", param.tokenName.data)) { // while we aren't on closing bracket
                        if (param.nextToken != NULL) {
                            switch (param.tokenType) {
                                case IDENT: // if this token is identifier
                                    if (param.nextToken->tokenType == INT || param.nextToken->tokenType == STRING ||
                                        param.nextToken->tokenType == FLOAT) { // next token can be only a datatype
                                        out = addToken(parameters, param.tokenType, param.tokenName.data);
                                        if (out) return out;
                                        i++;
                                        getToken(tokenList, i, &param);
                                    } else {
                                        deleteList(parameters);
                                        destroyString(&funcIdent);
                                        return SYNTAX_ERROR;
                                    }
                                    break;

                                case INT:
                                case FLOAT:
                                case STRING: // if this token is datatype
                                    if (param.nextToken->tokenType == COMMA || // next token can be either a comma or )
                                        equalStrings(")", param.nextToken->tokenName.data)) {
                                        addToken(parameters, param.tokenType,
                                                 param.tokenName.data); // ad the token to parameters list
                                        i++;
                                        getToken(tokenList, i, &param); // continue to next token
                                    } else {
                                        deleteList(parameters);
                                        destroyString(&funcIdent);
                                        return SYNTAX_ERROR;
                                    }
                                    break;

                                case COMMA: // if this token is a comma
                                    if (param.nextToken->tokenType == IDENT || param.nextToken->tokenType == EOL) {
                                        addToken(parameters, param.tokenType,
                                                 param.tokenName.data); // next token can be identifier or eol
                                        i++;
                                        getToken(tokenList, i, &param);
                                    } else {
                                        deleteList(parameters);
                                        destroyString(&funcIdent);
                                        return SYNTAX_ERROR;
                                    }
                                    break;
                                case EOL: // if this token is eol
                                    if (param.nextToken->tokenType == EOL || param.nextToken->tokenType == IDENT) {
                                        // next token can be identifier or another eol
                                        i++;
                                        getToken(tokenList, i, &param);
                                    } else {
                                        deleteList(parameters);
                                        destroyString(&funcIdent);
                                        return SYNTAX_ERROR;
                                    }
                                    break;
                                default: // if there is anything except eols, idents, commas and datatypes, it's syntax error
                                    deleteList(parameters);
                                    destroyString(&funcIdent);
                                    return SYNTAX_ERROR;
                            }
                        } else {
                            deleteList(parameters);
                            destroyString(&funcIdent);
                            return SYNTAX_ERROR;
                        }

                    } // po while  ->  FUNC IDENT ( TYPE IDENT , ... *)*

                    dataType *retTypesArray = malloc(100 * sizeof(dataType));
                    for (int iter = 0; iter < 100; iter++) retTypesArray[iter] = TYPE_UNDEFINED;

                    if (param.nextToken != NULL && equalStrings("(", param.nextToken->tokenName.data)) {

                        i += 2; // jump right to datatype token
                        token returnTypes;
                        getToken(tokenList, i, &returnTypes); // FUNC IDENT ( TYPE IDENT , ... ) *(* ...
                        if (returnTypes.nextToken != NULL) {

                            int count = 0;
                            while (!equalStrings(")", returnTypes.tokenName.data)) {
                                if (returnTypes.nextToken != NULL) {
                                    switch (returnTypes.tokenType) {
                                        case INT:
                                            if (returnTypes.nextToken->tokenType == COMMA ||
                                                returnTypes.nextToken->tokenType == BRACKET_ROUND) {
                                                retTypesArray[count] = TYPE_INT;
                                                count++;
                                            } else {
                                                deleteList(parameters);
                                                destroyString(&funcIdent);
                                                return SYNTAX_ERROR;
                                            }
                                            break;
                                        case FLOAT:
                                            if (returnTypes.nextToken->tokenType == COMMA ||
                                                returnTypes.nextToken->tokenType == BRACKET_ROUND) {
                                                retTypesArray[count] = TYPE_FLOAT;
                                                count++;
                                            } else {
                                                deleteList(parameters);
                                                destroyString(&funcIdent);
                                                return SYNTAX_ERROR;
                                            }
                                            break;
                                        case STRING:
                                            if (returnTypes.nextToken->tokenType == COMMA ||
                                                returnTypes.nextToken->tokenType == BRACKET_ROUND) {
                                                retTypesArray[count] = TYPE_STRING;
                                                count++;
                                            } else {
                                                deleteList(parameters);
                                                destroyString(&funcIdent);
                                                return SYNTAX_ERROR;
                                            }
                                            break;
                                        case COMMA:
                                            if (returnTypes.nextToken->tokenType == INT ||
                                                returnTypes.nextToken->tokenType == FLOAT ||
                                                returnTypes.nextToken->tokenType == STRING) {

                                            } else {
                                                deleteList(parameters);
                                                destroyString(&funcIdent);
                                                return SYNTAX_ERROR;
                                            }
                                            break;

                                        default:
                                            deleteList(parameters);
                                            destroyString(&funcIdent);
                                            return SYNTAX_ERROR;

                                    }
                                    i++;
                                    getToken(tokenList, i, &returnTypes);
                                } else {
                                    deleteList(parameters);
                                    destroyString(&funcIdent);
                                    return SYNTAX_ERROR;
                                }

                            } // FUNC IDENT ( TYPE IDENT , ... ) ( RET_TYPE, ... *)*

                            if (returnTypes.nextToken != NULL &&
                                equalStrings("{", returnTypes.nextToken->tokenName.data)) {
                                i++;
                                getToken(tokenList, i,
                                         &returnTypes); // FUNC IDENT ( IDENT TYPE , ... ) ( RET_TYPE, ... ) *{*
                                if (returnTypes.nextToken != NULL && returnTypes.nextToken->tokenType == EOL) {
                                    if (copyNode(globalTable, funcIdent.data) == NULL) {
                                        insertNode(globalTable, funcIdent.data, retTypesArray, parameters, 0);
                                        destroyString(&funcIdent);
                                    } else {
                                        deleteList(parameters);
                                        destroyString(&funcIdent);
                                        return DEFINITION_ERROR;
                                    }
                                } else {
                                    deleteList(parameters);
                                    destroyString(&funcIdent);
                                    return SYNTAX_ERROR;
                                }
                            }

                        } else {
                            deleteList(parameters);
                            destroyString(&funcIdent);
                            return SYNTAX_ERROR;
                        }

                    } else {
                        if (param.nextToken != NULL && equalStrings("{", param.nextToken->tokenName.data)) {
                            i++;
                            getToken(tokenList, i, &param); // FUNC IDENT ( TYPE IDENT , ... ) *{*
                            if (param.nextToken != NULL &&
                                param.nextToken->tokenType == EOL) { // after { must be an eol
                                if (copyNode(globalTable, funcIdent.data) == NULL) {
                                    insertNode(globalTable, funcIdent.data, retTypesArray, parameters, 0);
                                    destroyString(&funcIdent);
                                } else {
                                    deleteList(parameters);
                                    destroyString(&funcIdent);
                                    return DEFINITION_ERROR;
                                }
                            } else {
                                deleteList(parameters);
                                destroyString(&funcIdent);
                                return SYNTAX_ERROR;
                            }
                        } else {
                            deleteList(parameters);
                            destroyString(&funcIdent);
                            return SYNTAX_ERROR;
                        }
                    }
                } else {
                    destroyString(&funcIdent);
                    return SYNTAX_ERROR;
                }

            } else {
                destroyString(&funcIdent);
                return SYNTAX_ERROR;
            }
        }
    }

    return OK;
}

//check if the line is "package main"
errorCode blockPackage(list *tokenList) {
    token curToken;
    getToken(tokenList, 0, &curToken);

    while (curToken.tokenType == EOL)
        curToken = *curToken.nextToken;

    if (curToken.tokenType != PACKAGE) return SYNTAX_ERROR;

    curToken = *curToken.nextToken;

    if (strcmp(curToken.tokenName.data, "main") != 0) return SYNTAX_ERROR;

    return OK;

}

//checks for correct number of curly brackets
errorCode blockBrackets(list *tokenList) {

    token curToken;
    getToken(tokenList, 0, &curToken);

    int openBracketCount = 0;
    int closedBracketCount = 0;

    while (curToken.nextToken != NULL) {

        if (curToken.nextToken == NULL)
            if (openBracketCount != closedBracketCount) return SYNTAX_ERROR;
        curToken = *curToken.nextToken;


        if (curToken.tokenType == BRACKET_CURLY) {
            if (equalStrings(curToken.tokenName.data, "{")) {
                openBracketCount++;
            } else {
                closedBracketCount++;
            }
        }
    }


    if (openBracketCount != closedBracketCount) return SYNTAX_ERROR;

    return OK;

}

//syntax for expressions
errorCode blockExpression(token curToken, bool forState, bool expressionList) {

    int openBracketCount = 0;
    int closedBracketCount = 0;

    while (curToken.tokenType != EOL) {
        if (forState && curToken.tokenType == SEMICOL) return OK;

        if (!expressionList && curToken.nextToken->tokenType == COMMA) return SYNTAX_ERROR;

        if (curToken.tokenType == COMMA)
            if (curToken.nextToken->tokenType != IDENT && curToken.nextToken->tokenType != INT_LIT &&
                curToken.nextToken->tokenType != FLOAT_LIT &&
                curToken.nextToken->tokenType != STRING_LIT)

                if (curToken.tokenType == BRACKET_ROUND && equalStrings(curToken.tokenName.data, "(")) {
                    openBracketCount++;
                    if (curToken.nextToken->tokenType != IDENT) return SYNTAX_ERROR;
                    curToken = *curToken.nextToken;
                    continue;
                }

        if (curToken.tokenType == BRACKET_ROUND && equalStrings(curToken.tokenName.data, ")")) {
            closedBracketCount++;
            if (curToken.nextToken->tokenType != ARIT_OPERATOR && curToken.nextToken->tokenType != COMP_OPERATOR &&
                curToken.nextToken->tokenType != EOL)
                return SYNTAX_ERROR;
            curToken = *curToken.nextToken;
            continue;
        }

        if (curToken.tokenType == IDENT || curToken.tokenType == INT_LIT || curToken.tokenType == FLOAT_LIT ||
            curToken.tokenType == STRING_LIT) {
            if (curToken.nextToken->tokenType != ARIT_OPERATOR && curToken.nextToken->tokenType != COMP_OPERATOR &&
                curToken.nextToken->tokenType != EOL &&
                curToken.nextToken->tokenType != BRACKET_CURLY &&
                curToken.nextToken->tokenType != SEMICOL)
                return SYNTAX_ERROR;
            curToken = *curToken.nextToken;
            continue;
        }

        if (curToken.tokenType == ARIT_OPERATOR || curToken.tokenType == COMP_OPERATOR) {
            if (curToken.nextToken->tokenType != IDENT && curToken.nextToken->tokenType != INT_LIT &&
                curToken.nextToken->tokenType != FLOAT_LIT &&
                curToken.nextToken->tokenType != STRING_LIT)
                return SYNTAX_ERROR;
            curToken = *curToken.nextToken;
            continue;
        }

        if (equalStrings(curToken.tokenName.data, "{")) {
            if (curToken.nextToken->tokenType != EOL) return SYNTAX_ERROR;
            curToken = *curToken.nextToken;
            continue;
        }


        return SYNTAX_ERROR;

    }

    if (openBracketCount != closedBracketCount) return SYNTAX_ERROR;

    return OK;
}

//syntax for assign commands
errorCode blockAssign(token curToken, bool forState) {

    int openBracketCount = 0;
    int closedBracketCount = 0;
    if (forState)
        if (equalStrings(curToken.tokenName.data, "{")) return OK;


    if (curToken.tokenType != IDENT) return SYNTAX_ERROR;

    while (curToken.tokenType != EOL) {
        if (curToken.tokenType == ASIGN_OPERATOR) {
            curToken = *curToken.nextToken;
            break;
        }
        if (curToken.tokenType == IDENT)
            if (curToken.nextToken->tokenType != COMMA && curToken.nextToken->tokenType != ASIGN_OPERATOR)
                return SYNTAX_ERROR;

        if (curToken.tokenType == COMMA)
            if (curToken.nextToken->tokenType != IDENT) return SYNTAX_ERROR;

        if (curToken.nextToken == NULL) return SYNTAX_ERROR;
        curToken = *curToken.nextToken;
    }


    while (curToken.tokenType != EOL) {
        if (forState && equalStrings(curToken.tokenName.data, "{")) break;

        if (curToken.tokenType == IDENT || curToken.tokenType == INT_LIT || curToken.tokenType == FLOAT_LIT ||
            curToken.tokenType == STRING_LIT) {

            if (curToken.nextToken->tokenType != ARIT_OPERATOR && curToken.nextToken->tokenType != BRACKET_ROUND &&
                curToken.nextToken->tokenType != ASIGN_OPERATOR && curToken.nextToken->tokenType != BRACKET_CURLY &&
                curToken.nextToken->tokenType != EOL)
                return SYNTAX_ERROR;

            if (!forState && curToken.nextToken->tokenType == BRACKET_CURLY) return SYNTAX_ERROR;
            if (forState && equalStrings(curToken.nextToken->tokenName.data, "}")) return SYNTAX_ERROR;

            if (curToken.nextToken->tokenType == BRACKET_ROUND &&
                equalStrings(curToken.nextToken->tokenName.data, ")"))
                return SYNTAX_ERROR;

            curToken = *curToken.nextToken;
            continue;
        }

        if (curToken.tokenType == ARIT_OPERATOR || curToken.tokenType == BRACKET_ROUND) {

            if (curToken.tokenType == BRACKET_ROUND && equalStrings(curToken.tokenName.data, ")"))
                return SYNTAX_ERROR;

            if (equalStrings(curToken.tokenName.data, "("))
                openBracketCount++;
            if (equalStrings(curToken.tokenName.data, ")"))
                closedBracketCount++;

            if (curToken.nextToken->tokenType != IDENT && curToken.nextToken->tokenType != INT_LIT &&
                curToken.nextToken->tokenType != FLOAT_LIT && curToken.nextToken->tokenType != STRING_LIT)
                return SYNTAX_ERROR;

            curToken = *curToken.nextToken;
            continue;
        }

    }
    if (openBracketCount != closedBracketCount) return SYNTAX_ERROR;

    return OK;
}

//syntax for definition commands
errorCode blockDefinition(token curToken, bool forState) {

    if (forState)
        if (curToken.tokenType == SEMICOL) return OK;

    if (curToken.tokenType != IDENT) return SYNTAX_ERROR;
    curToken = *curToken.nextToken;

    while (curToken.tokenType != ASIGN_OPERATOR) {

        if (curToken.tokenType == COMMA)
            if (curToken.nextToken->tokenType != IDENT) return SYNTAX_ERROR;


        if (curToken.tokenType == IDENT)
            if (curToken.nextToken->tokenType != COMMA && curToken.nextToken->tokenType != ASIGN_OPERATOR)
                return SYNTAX_ERROR;
        curToken = *curToken.nextToken;
    }

    if (curToken.tokenType != ASIGN_OPERATOR && !equalStrings(":=", curToken.tokenName.data)) return SYNTAX_ERROR;
    curToken = *curToken.nextToken;

    return blockExpression(curToken, forState, false);

}
//syntax for list of identifiers
errorCode blockIdentList(token curToken) {

    if (curToken.tokenType == STRING_LIT || curToken.tokenType == INT_LIT || curToken.tokenType == FLOAT_LIT ||
        curToken.tokenType == IDENT) {
        if (curToken.nextToken->tokenType != COMMA && curToken.nextToken->tokenType != BRACKET_ROUND)
            return SYNTAX_ERROR;
    } else if (curToken.tokenType == COMMA) {
        if (curToken.nextToken->tokenType != STRING_LIT && curToken.nextToken->tokenType != INT_LIT &&
            curToken.nextToken->tokenType != FLOAT_LIT &&
            curToken.nextToken->tokenType != IDENT)
            return SYNTAX_ERROR;
    } else if (equalStrings(curToken.tokenName.data, ")")) {
        if (curToken.tokenType != EOL) return SYNTAX_ERROR;
    } else {
        return SYNTAX_ERROR;

    }

    return OK;
}

//syntax for function calls
errorCode blockFunctionCall(token curToken) {
    errorCode returnError;
    curToken = *curToken.nextToken->nextToken;

    while (curToken.tokenType != BRACKET_ROUND) {

        returnError = blockIdentList(curToken);
        if (returnError != OK) return returnError;

        curToken = *curToken.nextToken;
    }

    if (equalStrings(curToken.tokenName.data, ")"))
        if (curToken.nextToken->tokenType != EOL) return SYNTAX_ERROR;

    return OK;
}

//syntax for function declaration
errorCode blockFunctionDeclare(token curToken) {

    if (curToken.tokenType != IDENT) return SYNTAX_ERROR;

    if (equalStrings(curToken.tokenName.data, "main")) {
        if (equalStrings(curToken.nextToken->tokenName.data, "("))
            if (equalStrings(curToken.nextToken->nextToken->tokenName.data, ")"))
                if (equalStrings(curToken.nextToken->nextToken->nextToken->tokenName.data, "{"))
                    if (curToken.nextToken->nextToken->nextToken->nextToken->tokenType == EOL)
                        return OK;
    }

    curToken = *curToken.nextToken;
    if (!equalStrings(curToken.tokenName.data, "(")) return SYNTAX_ERROR;
    curToken = *curToken.nextToken;

    while (curToken.tokenType != BRACKET_ROUND) {

        if (curToken.tokenType == IDENT) {
            if (curToken.nextToken->tokenType != STRING && curToken.nextToken->tokenType != FLOAT &&
                curToken.nextToken->tokenType != INT)
                return SYNTAX_ERROR;
        }

        if (curToken.tokenType == COMMA) {
            if (curToken.nextToken->tokenType != IDENT) return SYNTAX_ERROR;
        }

        if (curToken.tokenType == STRING || curToken.tokenType == FLOAT || curToken.tokenType == INT) {
            if (curToken.nextToken->tokenType != COMMA && !equalStrings(curToken.nextToken->tokenName.data, ")"))
                return SYNTAX_ERROR;

        }
        curToken = *curToken.nextToken;
    }


    if (!equalStrings(curToken.tokenName.data, ")")) return SYNTAX_ERROR;

    curToken = *curToken.nextToken;
    if (!equalStrings(curToken.tokenName.data, "(")) return SYNTAX_ERROR;
    curToken = *curToken.nextToken;

    if (curToken.tokenType == EOL) return OK;

    while (curToken.tokenType != BRACKET_ROUND) {

        if (curToken.tokenType == COMMA) {
            if (curToken.nextToken->tokenType != STRING && curToken.nextToken->tokenType != INT &&
                curToken.nextToken->tokenType != FLOAT)
                return SYNTAX_ERROR;
        }

        if (curToken.tokenType == STRING || curToken.tokenType == FLOAT || curToken.tokenType == INT) {
            if (curToken.nextToken->tokenType != COMMA && !equalStrings(curToken.nextToken->tokenName.data, ")"))
                return SYNTAX_ERROR;
        }

        curToken = *curToken.nextToken;
    }


    return OK;

}

errorCode parse(list *tokenList) {

    if (tokenList->first == NULL) {
        string* s = malloc(sizeof(string));
        gen.program = s;
        generatorInit();
        return OK;
    }
    tableNodePtr globalTable;
    data *currentFunc = NULL;
    int lineCount = 0;
    int ifCount = 0;
    int forCount = 0;

    list buffer;
    initList(&buffer);

    list ifStack;
    initList(&ifStack);


    initTable(&globalTable);
    errorCode returnError = fillSymtable(&globalTable, tokenList);
    if (returnError != OK) {
        return returnError;
    }

    tableNodePtr localTable;
    initTable(&localTable);

    list lineTable;
    initList(&lineTable);

    token curToken;
    getToken(tokenList, 0, &curToken);

    //skip eols until we find begining of code
    size_t iterationStart = 0;
    while (curToken.tokenType == EOL) {
        curToken = *curToken.nextToken;
        iterationStart++;
    }

    //load the first line
    while (curToken.tokenType != EOL) {
        addToken(&lineTable, curToken.tokenType, curToken.tokenName.data);
        curToken = *curToken.nextToken;
    }
    //check if is - package main
    returnError = blockPackage(tokenList);
    if (returnError) {
        return returnError;
    }
    //check if there is no curly bracket missing
    returnError = blockBrackets(tokenList);
    if (returnError != OK) {
        return returnError;
    }
    //give first line to the generator
    returnError = generatorHandle(&lineTable, tokenList, globalTable, localTable, &ifStack, currentFunc);
    if (returnError) return returnError;


    token savedToken;
    //go through the entire code
    for (size_t i = 2+iterationStart; i < tokenList->size; i++) {
        getToken(tokenList, i, &curToken);
        initList(&lineTable);
        lineCount++;


        //fill list with 1 line
        while (curToken.tokenType != EOL) {
            addToken(&lineTable, curToken.tokenType, curToken.tokenName.data);
            i++;

            if (curToken.nextToken == NULL) break;

            curToken = *curToken.nextToken;
        }
        if (lineTable.size == 0) {
            continue;
        }
        //check if there is curly bracket at the end of the line of if and for commands
        if (lineTable.first->tokenType == FOR || lineTable.first->tokenType == IF)
            if (lineTable.last->tokenType != BRACKET_CURLY || !equalStrings(lineTable.last->tokenName.data, "{")) {
                return SYNTAX_ERROR;
            }

        //add EOL at the end of the line
        addToken(&lineTable, curToken.tokenType, curToken.tokenName.data);



        //check if syntax
        if (lineTable.first->tokenType == IF) {
            returnError = blockExpression(*lineTable.first->nextToken, false, false);
            if (returnError) {
                return SYNTAX_ERROR;
            }
            ifCount++;

            int j = 0;
            savedToken = curToken;

            //save token in buffer for generator
            token ifToken;
            initString(&ifToken.tokenName);
            ifToken.tokenType = IF;
            char *ifName = malloc(50 * sizeof(char));
            sprintf(ifName, "%d", ifCount);

            makeString(ifName, &ifToken.tokenName);
            pushToken(&ifStack, &ifToken);
            destroyString(&ifToken.tokenName);

            //count how many chars until we reach else that belongs to this if
            int openBracket = 1;
            int closedBracket = 0;
            while (openBracket != closedBracket) {
                if (curToken.nextToken == NULL) {
                    return SYNTAX_ERROR;
                }
                curToken = *curToken.nextToken;
                j++;
                if (equalStrings(curToken.tokenName.data, "{"))
                    openBracket++;
                if (equalStrings(curToken.tokenName.data, "}"))
                    closedBracket++;
            }
            //save token in buffer used to check else
            char *name = malloc(50 * sizeof(char));
            sprintf(name, "%zu", i + j + 1);
            token temp = curToken;
            initString(&temp.tokenName);

            makeString(name, &temp.tokenName);
            pushToken(&buffer, &temp);
            destroyString(&temp.tokenName);

            free(name);
            free(ifName);

            if (curToken.nextToken->tokenType != ELSE) {
                return SYNTAX_ERROR;
            }

            curToken = savedToken;

        }
            //check for syntax
        else if (lineTable.first->tokenType == FOR) {

            token tempToken = *lineTable.first->nextToken;
            forCount++;

            //save for in buffer used by generator
            token temp;
            initString(&temp.tokenName);
            temp.tokenType = FOR;
            char *forName = malloc(50 * sizeof(char));
            sprintf(forName, "%d", forCount);
            makeString(forName, &temp.tokenName);
            pushToken(&ifStack, &temp);
            //check for definition
            returnError = blockDefinition(tempToken, true);
            if (returnError) {
                return returnError;
            }

            while (tempToken.tokenType != SEMICOL) {
                if (tempToken.nextToken == NULL) {
                    return SYNTAX_ERROR;
                }
                tempToken = *tempToken.nextToken;
            }
            //check for expression
            returnError = blockExpression(*tempToken.nextToken, true, false);
            if (returnError) {
                return returnError;
            }

            do {
                if (tempToken.nextToken == NULL) return SYNTAX_ERROR;
                tempToken = *tempToken.nextToken;
            } while (tempToken.tokenType != SEMICOL);
            //check for assign command
            returnError = blockAssign(*tempToken.nextToken, true);
            if (returnError) {
                return returnError;
            }
        }
            //check return syntax
        else if (lineTable.first->tokenType == RETURN) {
            if (lineTable.first->nextToken->tokenType != EOL) {
                returnError = blockExpression(*lineTable.first->nextToken, false, true);
                if (returnError) {
                    return returnError;
                }
            }
        }
            //check sytax of definition, asighn commands and function calls
        else if (lineTable.first->tokenType == IDENT) {
            token tempToken = *lineTable.first;

            while (tempToken.tokenType != EOL) {
                if (tempToken.tokenType == ASIGN_OPERATOR) break;
                tempToken = *tempToken.nextToken;
            }

            //check syntax of definition command
            if (equalStrings(tempToken.tokenName.data, ":=")) {
                //check syntax of definition command with function call
                if (tempToken.nextToken->tokenType == IDENT &&
                    tempToken.nextToken->nextToken->tokenType == BRACKET_ROUND) {
                    token savedTemp = *lineTable.first;
                    while (savedTemp.tokenType != ASIGN_OPERATOR) {
                        blockIdentList(savedTemp);
                        savedTemp = *savedTemp.nextToken;
                    }

                    returnError = blockFunctionCall(*tempToken.nextToken);
                    if (returnError) {
                        return returnError;
                    }

                }
                //check syntax of definition command
                else {
                    returnError = blockDefinition(*lineTable.first, false);
                    if (returnError) {
                        return returnError;
                    }
                }


            }
                //check syntax of asign command
            else if (equalStrings(tempToken.tokenName.data, "=")) {
                token savedTemp = *lineTable.first;
                while (savedTemp.tokenType != ASIGN_OPERATOR) {
                    blockIdentList(savedTemp);
                    savedTemp = *savedTemp.nextToken;
                }
                //check syntax of assign command with function call
                if (tempToken.nextToken->tokenType == IDENT &&
                    tempToken.nextToken->nextToken->tokenType == BRACKET_ROUND) {
                    returnError = blockFunctionCall(*tempToken.nextToken);
                    if (returnError) {
                        return returnError;
                    }

                }
                //check syntax of assign command
                else {
                    returnError = blockAssign(*lineTable.first, false);
                    if (returnError) {
                        return returnError;
                    }
                }


            }
                //check syntax of function call
            else {
                returnError = blockFunctionCall(*lineTable.first);
                if (returnError) {
                    return returnError;
                }


            }
        }

            //check syntax of function definition
        else if (lineTable.first->tokenType == FUNC) {

            currentFunc = copyNode(&globalTable, lineTable.first->nextToken->tokenName.data);

            for (token* param = lineTable.first->nextToken->nextToken; param != NULL; param = param->nextToken) {
                if (param->tokenType == IDENT) {
                    dataType *dataTypes = malloc(sizeof(dataType) * 2);
                    dataTypes[1] = TYPE_UNDEFINED;
                    switch (param->nextToken->tokenType) {
                        case INT:
                            dataTypes[0] = TYPE_INT;
                            break;
                        case STRING:
                            dataTypes[0] = TYPE_STRING;
                            break;
                        case FLOAT:
                            dataTypes[0] = TYPE_FLOAT;
                            break;
                        default:
                            return SYNTAX_ERROR;
                    }
                    insertNode(&localTable, param->tokenName.data, dataTypes, NULL, 0);
                } else if (equalStrings(param->tokenName.data, ")")) {
                    break;
                }
            }

            returnError = blockFunctionDeclare(*lineTable.first->nextToken);
            if (returnError) {
                return returnError;
            }
        }
        //check else syntax - check if there is curly bracket before else and if it is written with correct if
        if (equalStrings(lineTable.first->tokenName.data, "}")) {
            if (lineTable.first->nextToken != NULL)
                if (lineTable.first->nextToken->tokenType == ELSE) {
                    if ((size_t)atoi(buffer.first->tokenName.data) != i + 1 - (lineTable.size - 1)) {
                        return SYNTAX_ERROR;
                    }
                    popToken(&buffer);
                }
        }
        //call semantic analyser and generator functions
        if (lineTable.first->tokenType != FUNC) {
            returnError = semanticAnalyser(&lineTable, &globalTable, &localTable, currentFunc);
            if (returnError)
                return returnError;
        }
        returnError = generatorHandle(&lineTable, tokenList, globalTable, localTable, &ifStack, currentFunc);
        if (returnError)
            return returnError;
        deleteList(&lineTable);

    }

    return OK;
}